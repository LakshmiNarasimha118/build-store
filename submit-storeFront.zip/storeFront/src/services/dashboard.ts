import Client from '../database'
import {Product} from '../models/userorderProduct'
import {Order} from '../models/userorderProduct'

export class DashboardQueries{
    async categoryOfTheProduct(category: String): Promise<Product[]>{
            const connection = await Client.connect();
            const postgress = 'SELECT * FROM products WHERE category = ($1)';

            const final = await connection.query(postgress, [category]);
            connection.release();

            return final.rows
    }


    async IdOfUser(userId: number): Promise<Order[]>{
            const connection = await Client.connect();
            const postgress = 'SELECT * FROM orders where user_id = ($1)';

            const final = await connection.query(postgress, [userId]);
            connection.release();

            return final.rows
    }
    async IdOfUsere(userId: number): Promise<Order[]>{
        const connection = await Client.connect();
        const postgress = 'SELECT * FROM orders where user_id = ($1)';

        const final = await connection.query(postgress, [userId]);
        connection.release();

        return final.rows
}


    async orderCompletedWithId(userId: number): Promise<Order[]>{
            const connection = await Client.connect();
            const postgress = 'SELECT * FROM orders where user_id = ($1) AND status = \'complete\'';

            const final = await connection.query(postgress, [userId]);
            connection.release();

            return final.rows
        
    }

    async highRatedProducts(): Promise<Product[]>{
            const connection = await Client.connect();
            const postgress = 'SELECT name, price, category, SUM(quantity) FROM products INNER JOIN order_products ON products.id = order_products.product_id GROUP BY products.id ORDER BY SUM(quantity) DESC LIMIT 5';

            const final = await connection.query(postgress);
            connection.release();

            return final.rows
    }
}