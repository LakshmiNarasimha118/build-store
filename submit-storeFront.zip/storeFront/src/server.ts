import express, { Request, Response } from 'express'
import userRoutes from './routeHandlers/userRoutes'
import orderRoutes from './routeHandlers/orderRoutes'
import productRoutes from './routeHandlers/productRoutes'
import dashboardRoutes from './routeHandlers/dashboardRoutes'


const app: express.Application = express()
const port = 3000 || process.env.PORT

app.use(express.json())

app.get('/', getFunc);

function getFunc (req: Request, res: Response){
    res.send('<h2>Welcome...!</h2>')
}

userRoutes(app);
orderRoutes(app);
productRoutes(app);
dashboardRoutes(app);

app.listen(port, function () {
    console.log(`Server listening at: ${port}`)
})

export default app;
