import dbConfig from '../database'
import dotenv from 'dotenv';
import bcrypt from 'bcrypt'

export type Order = {
    id: Number;
    status: String;
    user_id: string;
}

export type OrderProduct = {
  id: number;
  order_id: string;
  product_id: string;
  quantity: number;
};

export class OrderStore {
    remove(remove: any) {
        throw new Error('Method not implemented.');
    }
    async create(o: Order): Promise<Order> {
        
          const sql = 'INSERT INTO orders (status, user_id) VALUES($1, $2) RETURNING *'
          const connection = await dbConfig.connect()
          const result = await connection.query(sql, [o.status, o.user_id])
          const order = result.rows[0]
      
          connection.release()
          return order
        
    }

    async index(): Promise<Order[]> {
        
          const connection = await dbConfig.connect()
          const sql = 'SELECT * FROM orders'
          const result = await connection.query(sql)
      
          connection.release()
          return result.rows 
        
      }
      async indexe(): Promise<Order[]> {
        
        const connection = await dbConfig.connect()
        const sql = 'SELECT * FROM orders'
        const result = await connection.query(sql)
    
        connection.release()
        return result.rows 
      
    }
  
    async show(id: string): Promise<Order> {
        
          const sql = 'SELECT * FROM orders WHERE id=($1)'
          const connection = await dbConfig.connect()
          const result = await connection.query(sql, [id])
          connection.release()
    
        return result.rows[0]
        
      }

    async addProduct(quantity: number, order_id: string, product_id: string): Promise<{id:number, quantity:number, product_id: string, order_id: string}> {
      try {
        const ordersql = 'SELECT * FROM orders WHERE id=($1)'
        const connection = await dbConfig.connect()
        const result = await connection.query(ordersql, [order_id])
        const order = result.rows[0]

        if (order.status !== "active") {
          throw new Error(`Error adding product ${product_id} to order ${order_id}, ${order.status}`)
        }
        connection.release()
      } catch (err) {
        throw new Error(`${err}`)
      }

        try {
          const sql = 'INSERT INTO order_products (quantity, order_id, product_id) VALUES($1, $2, $3) RETURNING *'
          const connection = await dbConfig.connect()
          const result = await connection
              .query(sql, [quantity, order_id, product_id])
          const order_products = result.rows[0]
    
          connection.release()
          return order_products
        } catch (err) {
          throw new Error(`Error adding product ${product_id} to order ${order_id}: ${err}`)
        }
      }
}



export type Product = {
     id?: Number;
     name: String;
     price: number;
     category?: string;
}

export class ProductStore {
  update(update: any) {
      throw new Error('Method not implemented.')
  }
  remove(remove: any) {
      throw new Error('Method not implemented.')
  }
  async index(): Promise<Product[]> {

      const conn = await dbConfig.connect()
      const sql = 'SELECT * FROM products'
      const result = await conn.query(sql)
      conn.release()
      return result.rows 
    
  }

  async indexe(): Promise<Product[]> {

    const conn = await dbConfig.connect()
    const sql = 'SELECT * FROM products'
    const result = await conn.query(sql)
    conn.release()
    return result.rows 
  
}

  async show(id: string): Promise<Product> {
    
    const sql = 'SELECT * FROM products WHERE id=($1)'
    const conn = await dbConfig.connect()
    const result = await conn.query(sql, [id])
    conn.release()
    return result.rows[0]
   
  }

  async create(p: Product): Promise<Product> {

        const sql = 'INSERT INTO products (name, price, category) VALUES($1, $2, $3) RETURNING *'
        const conn = await dbConfig.connect()
        const category = p.category ?? null
        const result = await conn
            .query(sql, [p.name, p.price, category])
        const book = result.rows[0]
        conn.release()
        return book
      
  }
}



dotenv.config()

const {BCRYPT_PASSWORD, SALT_ROUNDS} = process.env

export type User = {
    id: number;
    username: string;
    firstname: string;
    lastname: string;
    password: string;
}

export class UserStore{

    async create(u: User): Promise<{"id":number, "username": string, "firstname":string, 'lastname':string}> {
          const sql = 'INSERT INTO users (username, firstname, lastname, password_digest) VALUES($1, $2, $3, $4) RETURNING *'
          const conn = await dbConfig.connect()
          const hash = bcrypt.hashSync(
              u.password + BCRYPT_PASSWORD!,
              parseInt(SALT_ROUNDS!)
          )
          const result = await conn
              .query(sql, [u.username, u.firstname, u.lastname, hash])
          const newUser = result.rows[0]
          conn.release()
          return {'id': newUser.id, "username": newUser.username, "firstname":newUser.firstname, 'lastname':newUser.lastname }
        
    }

    async index(): Promise<{"id":number, "username": string, "firstname":string, 'lastname':string}[]> {
       
          const conn = await dbConfig.connect()
          const sql = 'SELECT * FROM users'
          const result = await conn.query(sql)
          conn.release()
          let arr:{"id":number, "username": string, "firstname":string, 'lastname':string}[] = []
          result.rows.forEach((element: User) => {
            arr.push({'id': element.id ?? 0, 'username': element.username, 'firstname':element.firstname ?? '', 'lastname':element.lastname ?? ''})
          })
          return arr
      }
    
      async show(id: string): Promise<{"id":number, "username": string, "firstname":string, 'lastname':string}> {
          const sql = 'SELECT * FROM users WHERE id=($1)'
          const conn = await dbConfig.connect()      
          const result = await conn.query(sql, [id])
          conn.release()
          return {'id': result.rows[0].id, "username": result.rows[0].username, "firstname":result.rows[0].firstname, 'lastname':result.rows[0].lastname }
        
      }
      async update(id: string): Promise<{"id":number, "username": string, "firstname":string, 'lastname':string}> {
        const sql = 'SELECT * FROM users WHERE id=($1)'
        const conn = await dbConfig.connect()      
        const result = await conn.query(sql, [id])
        conn.release()
        return {'id': result.rows[0].id, "username": result.rows[0].username, "firstname":result.rows[0].firstname, 'lastname':result.rows[0].lastname }
      
    }
    

    async authenticate(username: string, password: string): Promise<User|null> {
        
          const sql = 'SELECT * FROM users WHERE username = ($1)'
          const conn = await dbConfig.connect()
          const result = await conn.query(sql, [username])
          conn.release()
          if(result.rows && result.rows.length){
            const user = result.rows[0]
            if (bcrypt.compareSync(password + BCRYPT_PASSWORD, user.password_digest)) return user
          }
          return null
        
    }

}