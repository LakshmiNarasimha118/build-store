import { DashboardQueries } from '../services/dashboard'
import { token } from '../middleware/authentication'
import express, { Request, Response } from 'express'


const dashboardRoutes = (app: express.Application) => {
    app.get('/products-by-category',productFunc);
    
    async function  productFunc(req: Request, res: Response){
        try{
            const products = await dashboard.categoryOfTheProduct(req.body.category);
            res.json(products);
        }
        catch(err){
            res.status(400)
            res.json(err)
        }
    }
    app.get('/order-by-userid', token,orderbyuserfunc);
    
    async function  orderbyuserfunc(req: Request, res: Response){
        try{
            const orders = await dashboard.IdOfUser(req.body.user_id);
            res.json(orders);
        }
        catch(err){
            res.status(400)
            res.json(err)
        }
    }
    app.get('/complete-order-by-userid', token, async (req: Request, res: Response) => {
        try{
            const orders = await dashboard.orderCompletedWithId(req.body.user_id);
            res.json(orders);
        }
        catch(err){
            res.status(400)
            res.json(err)
        }
    })
    
    app.get('/five-most-popular-product', async (req: Request, res: Response) => {
        try{
            const products = await dashboard.highRatedProducts();
            res.json(products);
        }
        catch(err){
            res.status(400)
            res.json(err)
        }
    })
  }

const dashboard = new DashboardQueries();

export default dashboardRoutes