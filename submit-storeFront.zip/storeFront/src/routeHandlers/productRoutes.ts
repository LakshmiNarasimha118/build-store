import { Product, ProductStore } from '../models/userorderProduct'
import { token, RequestCustom } from '../middleware/authentication'
import express, { Request, Response } from 'express'

const store = new ProductStore();
  
const ProductRoutes = (app: express.Application) => {
    app.post('/products', token, async (_req: Request, res: Response) => {
        try {
            const product: Product = {
                name: _req.body.name,
                price: _req.body.price,
                category: _req.body.category ?? null
            }
            const newOrder = await store.create(product)
            res.json(newOrder)
        } catch(err) {
            console.log(err)
            res.status(400)
            res.json(err)
        }
    })
    app.get('/products',productFunc);
    
    async function productFunc (_req: Request, res: Response) {
        try {
            const products = await store.index()
            res.json(products)
        } catch(err) {
            console.log(err)
            res.status(400)
            res.json(err)
        }
    }
    app.get('/products/:id',token, async (req: Request, res: Response) => {
        const customReq = req as RequestCustom
        const product = await store.show(req.params.id)
        res.json(product)
    })
  }

export default ProductRoutes