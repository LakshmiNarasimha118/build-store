import jwt from 'jsonwebtoken'
import express, { Request, Response } from 'express'
import { User, UserStore } from '../models/userorderProduct'
import { token, RequestCustom } from '../middleware/authentication'

const store = new UserStore()
  
const userRoutes = (app:express.Application) => {
    app.post('/users', async (req: Request, res: Response) => {
        try {
            const user: User = {
                username: req.body.username,
                firstname: req.body.firstname,
                lastname: req.body.lastname,
                password: req.body.password,
                id: 0
            }
    
            const newUser = await store.create(user)
    
            let secret = jwt.sign({user: newUser}, process.env.TOKEN_SECRET!)
    
            res.json({'secret': secret})
        } catch(err) {
            res.status(400)
            res.json(err)
        }
    })

    app.get('/users', token,usersFunc);
    
    async function usersFunc (req: Request, res: Response){
        try {
            const users = await store.index()
            res.json(users)
        } catch(err) {
            res.status(400)
            res.json(err)
        }
    }

    app.get('/users/:id', token, async (req: Request, res: Response) => {
        try {
            const customReq = req as RequestCustom
            const user = await store.show(req.params.id)
            res.json(user)
        } catch(err) {
            res.status(400)
            res.json(err)
        }
    })
    app.post('/authenticate', async (req: Request, res: Response) => {
        try {
            const user: User = {
                username: req.body.username,
                password: req.body.password,
                id: 0,
                firstname: '',
                lastname: ''
            }
            const authUser = await store.authenticate(user.username, user.password)
            let secret = jwt.sign({user: authUser}, process.env.TOKEN_SECRET!)
            res.json({'secret': secret})
        } catch(err) {
            res.status(400)
            res.json(err)
        }
    })
}

export default userRoutes