import {User, UserStore} from '../../models/userorderProduct';
import {Order, OrderStore, OrderProduct} from '../../models/userorderProduct';
import {Product, ProductStore} from '../../models/userorderProduct';


const userstore = new UserStore();
const testPassword: string = process.env.POSTGRES_PASSWORD_TEST as string;

let user : User={
    username: 'user2',
    firstname: 'santosh',
    lastname: 'hima',
    password: testPassword,
    id: 0
}

describe('User model',userFunc);

function userFunc () {
    
    it('should have show method',showShoulFunc);

    it('show method should return single user',showFunc);

    it('should have create method',createShouldFunc);

    it('create method should add 1 user',createFunc);


    function showShoulFunc(){
        expect(userstore.show).toBeDefined();
    }
    
    async function showFunc() {
        const result = await userstore.show('1');
        expect(result).toEqual({
            id:1,
            username: 'user2',
            firstname: 'santosh',
            lastname: 'hima',
        })
    }
    
    function createShouldFunc() {
        expect(userstore.create).toBeDefined();
    }
    
    async function createFunc(){
        const result = await userstore.create(user)
        expect(result.username).toEqual(user.username)
        expect(result.firstname).toEqual('santosh')
        expect(result.id).toEqual(user.id)
    }

}


const orderstore = new OrderStore();

let order : Order={
    status: 'active',
    user_id: '1',
    id: 1
}

let orderProduct: OrderProduct = {
    id: 1,
    order_id: '1',
    product_id: '1',
    quantity: 1
};

describe('Order model',orderFunc);


function orderFunc(){

    it('should have index method',shoulFunc);

    it('index method should return non-empty list',indexFunc);

    it('should have show method',shoulshowFunc);

    it('show method should return single order',showFunc);

    it('should have create method',createshouldFunc);

    it('create method should add 1 order',createFunc);

    it('should have a delete method',delshouldFunc);

    it('should have an addProduct method',addproshoulFunc);

    it('addProduct method should add a product to the current order_product',addProductFunc);

    
    function shoulFunc() {
        expect(orderstore.index).toBeDefined();
    }

    
    async function indexFunc() {
        const result = await orderstore.index();
        expect(result.length).toBeGreaterThan(0);
    }

    
    function shoulshowFunc() {
        expect(orderstore.show).toBeDefined();
    }

    
    async function showFunc () {
        const result = await orderstore.show('1');
        expect(result.status).toEqual(order.status)
        expect(result.user_id).toEqual(order.user_id)
        expect(result.id).toEqual(order.id)
    }


    
    function createshouldFunc(){
        expect(orderstore.create).toBeDefined();
    }

    
    async function createFunc() {
        const result = await orderstore.create(order)
        expect(result.status).toEqual(order.status)
        expect(result.user_id).toEqual(order.user_id)
        expect(result.id).toEqual(order.id)
    }
    
    function delshouldFunc()  {
        expect(orderstore.remove).toBeDefined();
    };

    
    function addproshoulFunc() {
        expect(orderstore.addProduct).toBeDefined();
    };
    
    async function addProductFunc(){
        const result = await orderstore.addProduct(1, '1', '1');
        expect(Number(result.order_id)).toEqual(1);
        expect(Number(result.product_id)).toEqual(1);
        expect(result.quantity).toEqual(1);
        
    }
}



const productstore = new ProductStore();

let product : Product ={
    id:1,
    name: 'car',
    price: 10000,
    category: 'swift'
}

describe('Product model',productFunc);

function productFunc(){
    it('should have index method',indexSFunc);
    it('index method should return non-empty list',indexFunc);
    it('should have show method',shouldFunc);
    it('show method should return single product',showFunc);
    it('should have create method',createsholuFunc);
    it('create method should add 1 product',createFunc);

    it('update method should should correctly update product information',updateFunc);
    it('should have a delete method',delshoulFunc);
    it('delete method should remove the correct product',deleteFunc);
    it('should have an update method',upshoulFunc);


    function indexSFunc()  {
        expect(productstore.index).toBeDefined();
    }
    
    async function indexFunc() {
        const result = await productstore.index();
        expect(result.length).toBeGreaterThan(0);
    }
    
    function shouldFunc() {
        expect(productstore.show).toBeDefined();
    }

    
    async function showFunc () {
        const result = await productstore.show('1');
        expect(result.name).toEqual(product.name)
        expect(result.id).toEqual(product.id)
    }
    
    function createsholuFunc(){
        expect(productstore.create).toBeDefined();
    }


    async function createFunc(){
        const result = await productstore.create(product)
        expect(result.name).toEqual(product.name)
        expect(result.id).toEqual(product.id)
        expect(result.price).toEqual(product.price)
        expect(result.category).toEqual(product.category)
    }
    
    function delshoulFunc() {
        expect(productstore.remove).toBeDefined();
    };
    
    async function deleteFunc () {
        const result = productstore.remove('car')
    };
    
    function upshoulFunc() {
        expect(productstore.update).toBeDefined();
    };
    
    async function  updateFunc() {
        const result = productstore.update({
            id: 1,
            name: 'car',
            price: 110000,
            category: 'swift'
        });
        
    };
}
