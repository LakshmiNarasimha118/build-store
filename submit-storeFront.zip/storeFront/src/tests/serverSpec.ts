import supertest from 'supertest';
import app from '../server';

const request = supertest(app);

let token: string;

describe('Test endpoint responses',testFunc);

function testFunc(){

    beforeAll(async () => {
        const response = await request.post('/authenticate')
            .send({'username':'user1', 'password':'password123'});
        token = response.body.token;
    })

    describe('User endpoint',userFunc);

    describe('Product endpoint',productFunc);

    describe('Order endpoint',orderFunc);

    describe('Dashboard endpoint',dashboardFunc);
    
    function userFunc(){

        it('Create user endpoint',userCreateFunc);

        it('Authenticate user endpoint',userAutheFunc);

        it('Authorized index user endpoint',userindexauFunc);

        it('Authorized show user endpoint',userShowFunc);
        
        async function userCreateFunc (){
            const response = await request.post('/users');
            expect(response.status).toBe(200);
          };
          
          async function userAutheFunc () {
            const response = await request.post('/authenticate')
            expect(response.status).toBe(200);
          };
          
          async function userindexauFunc (){
            const response = await request.get('/users')
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
          };
          
          async function  userShowFunc(){
            const response = await request.get('/users/1')
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
          };

    };
    
    
    function productFunc() {

        it('Authorized create product endpoint',proautherFunc);

        it('Index product endpoint',proindexFunc);

        it('Authorized show product endpoint',proshowauFunc);
        
        async function proautherFunc () {
            const response = await request.post('/products')
            .send({'name':'fork', 'price':5})
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
          };

          
          async function  proindexFunc() {
            const response = await request.get('/products');
            expect(response.status).toBe(200);
          };
          
          async function proshowauFunc (){
            const response = await request.get('/products/1')
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
          };

    };
    
    function orderFunc() {

        it('Authorized create order endpoint',orderauFunc);

        it('Index order endpoint',ordeindexFunc);

        it('Authorized show order endpoint',ordershowauFunc);

        it('Authorized addProduct order endpoint',orderaddproauFunc);

        
        async function orderauFunc (){
            const response = await request.post('/orders')
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
          };
          
          async function ordeindexFunc (){
            const response = await request.get('/orders');
            expect(response.status).toBe(200);
          };
          
          async function ordershowauFunc (){
            const response = await request.get('/orders/1')
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
          };
          
          async function orderaddproauFunc () {
            const response = await request.post('/orders/1/products')
            .send({'quantity':5, 'product_id':'1'})
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
          };

    };
    
    function dashboardFunc() {
        it('Products by category endpoint',dashboardproductFunc);

        it('Authorized  order by user id endpoint',dashboardauthFunc);

        it('Five most popular product endpoint',dashboardfiveFunc);

        it('Authorized completed order by user id endpoint',dashboardauFunc);
        
        async function dashboardproductFunc (){
            const response = await request.get('/products-by-category');
            expect(response.status).toBe(200);
        };
        
        async function dashboardauthFunc (){
            const response = await request.get('/order-by-userid')
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
        };
        
        async function dashboardfiveFunc (){
            const response = await request.get('/five-most-popular-product');
            expect(response.status).toBe(200);
        };
        
        async function dashboardauFunc (){
            const response = await request.get('/complete-order-by-userid')
            .set('Authorization', 'Bearer ' + token);
            expect(response.status).toBe(200);
        };

    };
};
