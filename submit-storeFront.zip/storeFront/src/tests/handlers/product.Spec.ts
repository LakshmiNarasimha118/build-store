import supertest from 'supertest';
import Clinte from '../../database';
import app from '../../server';
import {ProductStore, Product} from '../../models/userorderProduct';
import {UserStore , User} from '../../models/userorderProduct';

const productStore = new ProductStore();
const userStore = new UserStore();
const request = supertest(app);
let token = '';

describe('PRODUCT API Endpoints',productFunc);

async function productFunc (){
	const newUser = {
		username: 'user',
		firstname: 'kiran',
		lastname: 'manam',
		password: 'test123',
	}  as User;

	const newP = {
		name: 'Book',
		price: 400.22,
		category: 'nature',
	} as Product;

	beforeAll(async () => {
		await userStore.create(newUser);
		const createNewP = await productStore.create(newP);
		newP.id = createNewP.id;

		const auth = await request
			.post('/users/login')
			.set('Content-type', 'application/json')
			.send({
				email: 'm.kiran@info.com',
				password: 'test123',
			});
		const { accessToken } = auth.body.data;
		token = accessToken;
	});

	afterAll(async () => {
		const conn = await Clinte.connect();
		const sql = 'DELETE FROM products';
		const sqlU = 'DELETE FROM users;';
		await conn.query(sql);
		await conn.query(sqlU);
		conn.release();
	});

	
		describe('==> CREATE / ROUTE',createFunc);
		describe('==> INDEX ALL Product / ROUTE',indexFunc);
		describe('==> SHOW ONE product BY ID / ROUTE',showFunc);
		describe('==> UPDATE product  / ROUTE',updateFunc);
		describe('==> DELETE product BY ID / ROUTE',deleteFunc);
		
		function createFunc() {
			it(' RETURN STATUS(200) and NEW PRODUCT',returnFunc);

			it('VALIDATION RETURN ERROE WITH  INVALID PRODUCT INPUTS',validateFunc);

			
			async function  returnFunc() {
				const createP = await request
					.post('/products/')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						name: 'Removable Hooded ',
						price: 469.95,
						category: 'nature ',
					} as Product);
				expect(createP.status).toBe(200);
				expect(createP.body.data).toEqual({
					id: createP.body.data.id,
					name: 'Removable Hooded ',
					price: '469.95',
					category: 'nature',
				});
			};
			
			async function validateFunc ()  {
				const createP = await request
					.post('/users/')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						name: 'Removable Hooded ',
						price: 469.95,
						category: '',
					});

				expect(createP.status).not.toBe(200);
			};
		};
		
		function indexFunc() {
			it('SHOULD RETURN STATUS (200) & LIST OF PRODUCTS',shouldFunc);
			
			async function shouldFunc()  {
				const listP = await request.get('/products/').set({
					Authorization: 'Bearer ' + token,
				});
				const products = listP.body.data;
				expect(listP.status).toBe(200);
				expect(products.length).toBe(2);
			};
		};		
		function showFunc()  {
			it('SHOULD RETURN A TARGET product',returnFunc);
			
			async function returnFunc () {
				const showP = await request.get(`/products/${newP.id}`).set({
					Authorization: 'Bearer ' + token,
				});
				const product = showP.body.data;
				expect(showP.status).toBe(200);
				expect(product.id).toBe(newP.id);
			};
		};

		function removeFunce()  {
			it('SHOULD RETURN A TARGET product',returnFunc);
			
			async function returnFunc () {
				const showP = await request.get(`/products/${newP.id}`).set({
					Authorization: 'Bearer ' + token,
				});
				const product = showP.body.data;
				expect(showP.status).toBe(200);
				expect(product.id).toBe(newP.id);
			};
		};
		
		function updateFunc()  {
			it('should return res.status(200) and update a product',updshouldFunc);
			
			async function  updshouldFunc()  {
				const updateP = await request
					.patch(`/products/${newP.id}`)
					.set('Authorization', 'Bearer ' + token)
					.send({
						name: 'Moto Bike',
						price: 240,
						category: 'bike ',
					});

				expect(updateP.status).toBe(200);
				const { id, name, price, category } = updateP.body.data;
				expect(updateP.status).toBe(200);
				expect(id).toEqual(newP.id);
				expect(name).toEqual('r Moto Bike');
				expect(price).toEqual('240');
				expect(category).toEqual('bike');
			};
		};
		
		function deleteFunc()  {
			it('should return res.status(200) ',delshouldFunc);
			
			async function  delshouldFunc(){
				const deletP = await request
					.delete(`/products/${newP.id}`)
					.set('Authorization', 'Bearer ' + token);
				expect(deletP.status).toBe(200);
			};
		};
	
};
