import supertest from 'supertest';
import Clinte from '../../database';
import app from '../../server';
import {UserStore , User} from '../../models/userorderProduct';


const userStore = new UserStore();
const request = supertest(app);
let token = '';

describe('User API Endpoints',userFunc);


function userFunc() {
	const newUser = {
		username: 'user',
		firstname: 'kiran',
		lastname: 'manam',
		password: 'test123',
	}  as User ;

	beforeAll(async () => {
		const createdUser = await userStore.create(newUser);
		newUser.id = createdUser.id;
	});

	afterAll(async () => {
		const conn = await Clinte.connect();

		const sql = 'DELETE FROM users;';
		await conn.query(sql);
		conn.release();
	});

	describe('Test Authenticate methods',testFunc);

	describe('==> REGISTER / ROUTE',regisfunc);

	
	function testFunc()  {
		it('should be able to authenticate to get token',testShouldFunc);

		it('FAILD TO AUTHENTICATE WITH RWONG EMAIL',testFaildFunc);

		
		async function testShouldFunc () {
			const auth = await request
				.post('/users/login')
				.set('Content-type', 'application/json')
				.send({
					email: 'M.kiran@info.com',
					password: 'test123',
				});
			expect(auth.status).toBe(200);
			const { id, accessToken } = auth.body.data;
			expect(id).toBe(newUser.id);

			token = accessToken;
		};		
		async function  testFaildFunc(){
			const auth = await request
				.post('/api/users/login')
				.set('Content-type', 'application/json')
				.send({
					email: 'invalid@email.com',
					password: 'test123',
				});
			expect(auth.status).not.toBe(200);
		};
	};

		
		function regisfunc()  {
			it(' RETURN STATUS(200) and NEW USER',returnFunc);

			it(' WITHOUT ADMIN OR VALID TOKen RETURN ERROR ',withoutFunc);

			it('VALIDATION RETURN ERROE WITH  INVALID INPUTS',validFunc);

			it(' WITH EXIST EMAIL IN DB SHOULD RETURN ERORR',withFunc);
			
			async function  returnFunc() {
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
						role: 'admin',
					})
					.send({
						username: 'userTest',
						firstname: 'kiran22',
						lastname: 'manam22',
						password: 'test1232',
					});
				const { id, username, firstname, lastname } =
					register.body.data;
				expect(register.status).toBe(200);
				expect(id).toEqual(id);
				expect(username).toEqual('userTest');
				expect(firstname).toEqual('kiran22');
				expect(lastname).toEqual('manam22');
			};

			async function withoutFunc () {
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						username: 'userTest',
						firstname: 'kiran22',
						lastname: 'manam22',
						password: 'test1232',
					});

				expect(register.status).not.toBe(200);
			};

			
			async function validFunc()  {
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						username: '',
						firstname: 'kiran22',
						lastname: 'manam22',
						password: 'test1232',
					});

				expect(register.status).not.toBe(200);
			};

			async function validFunce()  {
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						username: '',
						firstname: 'kiran22',
						lastname: 'manam22',
						password: 'test1232',
					});

				expect(register.status).not.toBe(200);
			};
			
			async function withFunc () {
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						username: 'userTest',
						firstname: 'kiran22',
						lastname: 'manam22',
						password: 'test1232',
					});

				expect(register.status).not.toBe(200);
			};
		};

	
};

