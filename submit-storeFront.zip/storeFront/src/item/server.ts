import express, { Request, Response } from 'express'


const app: express.Application = express()
const port =5000 || process.env.PORT

app.use(express.json())

app.get('/', getFunc);

function getFunc (req: Request, res: Response){
    res.send('<h2>Welcome...!</h2>')
}

app.listen(port, function () {
    console.log(`Server listening at: ${port}`)
})

export default app;
