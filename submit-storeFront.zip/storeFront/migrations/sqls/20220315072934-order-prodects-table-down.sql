/* Replace with your SQL commands */

DROP TABLE order_products;